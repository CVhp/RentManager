module random {
}