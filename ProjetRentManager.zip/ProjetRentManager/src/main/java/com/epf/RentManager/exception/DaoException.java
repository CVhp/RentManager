package com.epf.RentManager.exception;

public class DaoException extends Exception {
    public DaoException (){
        super();
    }

    public DaoException(String msg){
        super(msg);
    }
}
